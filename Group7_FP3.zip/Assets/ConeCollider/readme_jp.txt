<<バージョン>>
1.0

<<更新情報>>
1.0
初期バージョン

<<使用方法>>
今までのコライダコンポーネント同様、ConeColliderコンポーネントをアタッチする

<<パラメータ>>
・Angle
ConeColliderの広がる角度

・Distance
現オブジェクトからの距離

・isTrigger
コライダのisTriggerを有効にするかどうか

・isFixScale
親子関係に関わらずスケールを固定するか

<<連絡>>
Twitter:@isemito_niko